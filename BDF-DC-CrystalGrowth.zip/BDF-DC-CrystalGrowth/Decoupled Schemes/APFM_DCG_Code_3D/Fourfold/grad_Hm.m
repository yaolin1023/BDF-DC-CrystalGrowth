function Hm_grad = grad_Hm(phi_hat,N,L)
%计算grad*(grad(m) + grad(H))
global sigma theta0 Phin0
%构造FFT
kx = (2*pi/L)*[0:N/2-1 -N/2:-1]; ky = kx; kz = ky; %频域坐标
[kX,kY,kZ] = meshgrid(kx,ky,kz)                           ; %生成频域网格
KX = kX.^2; KY = kY.^2; KZ = kZ.^2                          ;               

et = reshape(phi_hat,N,N,N); Dxx = ifftn(-KX.*et); Dyy = ifftn(-KY.*et); Dzz = ifftn(-KZ.*et); Dx = ifftn(sqrt(-1)*kX.*et); Dy = ifftn(sqrt(-1)*kY.*et); Dz = ifftn(sqrt(-1)*kZ.*et); Dxy = ifftn(-kX.*kY.*et); Dxz = ifftn(-kX.*kZ.*et); Dyz = ifftn(-kY.*kZ.*et);
Dxx = real(Dxx); Dyy = real(Dyy); Dzz = real(Dzz); Dx = real(Dx); Dy = real(Dy); Dz = real(Dz); Dxy = real(Dxy); Dxz = real(Dxz); Dyz = real(Dyz);

%%----------------m=4-------------X,Y,Z-direction%%
%%
theta    = atan2(sqrt(Dx.^2+Dy.^2),Dz); Phin=atan2(Dy,Dx);
apha1 = (1/64)*(-18 + 2*cos(4*Phin) - cos(4*Phin - 4*theta) - 32*cos(2*theta) - 14*cos(4*theta) - cos(4*Phin + 4*theta));
apha2 = (1/64)*(10 + 6*cos(4*Phin) + cos(4*Phin - 4*theta) - 4*cos(4*Phin - 2*theta) - 24*cos(2*theta) + 14*cos(4*theta) - 4*cos(4*Phin + 2*theta) + cos(4*Phin + 4*theta));
beta1 = (1/16)*(-2*sin(4*Phin) + sin(4*Phin - 2*theta) + sin(4*Phin + 2*theta));
Kappa=1-3*sigma+4*sigma*( (1/64)*(42 + 6*cos(4*Phin) + cos(4*Phin - 4*theta) -...
          4*cos(4*Phin - 2*theta) + 8*cos(2*theta) + 14*cos(4*theta) -... 
          4*cos(4*Phin + 2*theta) + cos(4*Phin + 4*theta)) );
Kappa2=Kappa.^2 ;

DxKappa2 = ifftn(sqrt(-1)*kX.*fftn(Kappa2)); DyKappa2 = ifftn(sqrt(-1)*kY.*fftn(Kappa2)); DzKappa2 = ifftn(sqrt(-1)*kZ.*fftn(Kappa2)); 
DxKappa2 = real(DxKappa2); DyKappa2 = real(DyKappa2); DzKappa2 = real(DzKappa2);
m_Kappa   = Kappa2.*(Dxx+Dyy+Dzz)+DxKappa2.*Dx+DyKappa2.*Dy+DzKappa2.*Dz;

HmKappax = 16*sigma*Kappa.*(apha1.*Dx-beta1.*Dy);
HmKappay = 16*sigma*Kappa.*(apha1.*Dy+beta1.*Dx);
HmKappaz = -16*sigma*Kappa.*apha2.*Dz                   ;


DxHmKappa   = ifftn(sqrt(-1)*kX.*fftn(HmKappax)); DyHmKappa = ifftn(sqrt(-1)*kY.*fftn(HmKappay)); DzHmKappa = ifftn(sqrt(-1)*kZ.*fftn(HmKappaz));
DxHmKappa   = real(DxHmKappa); DyHmKappa = real(DyHmKappa); DzHmKappa = real(DzHmKappa); 
Hm_Kappa     = DxHmKappa + DyHmKappa + DzHmKappa;

Hm_grad = fftn(m_Kappa+Hm_Kappa); %二三维FFT变换
Hm_grad = Hm_grad(:)                     ;

end


           
