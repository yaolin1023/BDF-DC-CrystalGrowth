function fu = Fu(phi)
%双井势函数
global epsilon

fu  = (1/(4*epsilon^2))*(phi.^2 - 1).^2; %计算双阱势函数
end