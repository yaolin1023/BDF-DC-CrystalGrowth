function [phi, u] = u_exact(x, y, t)
%analytical solution
phi = sin(x).*cos(y).*cos(t);
u   = cos(x).*sin(y).*cos(t); %最好
end
