function grad_m = m_grad(phi_0,N,L)
global sigma m theta0
%构造FFT
kx = (2*pi/L)*[0:N/2-1 -N/2:-1]; ky = kx; %频域坐标
[kX,kY] = meshgrid(kx,ky)                       ; %生成频域网格
KX = kX.^2; KY = kY.^2                               ;     

et = reshape(phi_0,N,N);  Dxx = ifft2(-KX.*et); Dyy = ifft2(-KY.*et); Dx = ifft2(sqrt(-1)*kX.*et); Dy = ifft2(sqrt(-1)*kY.*et); Dxy = ifft2(-kX.*kY.*et); 
Dxx = real(Dxx); Dyy = real(Dyy); Dx = real(Dx); Dy = real(Dy); %Dxy = real(Dxy);

%%
theta=atan2(Dy,Dx)                                           ;
Kappa=1+sigma*cos(m*(theta-theta0))             ;
Kappa2=Kappa.^2                                                ;
DxKappa2 = ifft2(sqrt(-1)*kX.*fft2(Kappa2)); DxKappa2 = real(DxKappa2);
DyKappa2 = ifft2(sqrt(-1)*kY.*fft2(Kappa2)); DyKappa2 = real(DyKappa2);
mxy = Kappa2.*(Dxx+Dyy)+DxKappa2.*Dx+DyKappa2.*Dy;
grad_m =mxy(:);

end
















