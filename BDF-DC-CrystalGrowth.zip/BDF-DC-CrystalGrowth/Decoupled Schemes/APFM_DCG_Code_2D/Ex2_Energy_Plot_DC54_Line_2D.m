clear all; close all;
%%
%BDF-DC_{5}^{4}; S1 = 4; S2 = 4;
figure
load('Energy_BDF54_T10_dt1.mat')
load('Energy_BDF54_T10_dt05.mat')
load('Energy_BDF54_T10_dt01.mat')
load('Energy_BDF54_T10_dt005.mat')
load('Energy_BDF54_T10_dt001.mat')

T = 10                     ; %终止时间
dt1 = 1/1                ; %时间剖分
Tt1 = (0:dt1:T)'    ; %时间层的节点剖分
dt2 = 1/2                ; %时间剖分
Tt2 = (0:dt2:T)'    ; %时间层的节点剖分
dt3 = 1/10              ; %时间剖分
Tt3 = (0:dt3:T)'    ; %时间层的节点剖分
dt4 = 1/20              ; %时间剖分
Tt4 = (0:dt4:T)'    ; %时间层的节点剖分
dt5 = 1/100             ; %时间剖分
Tt5 = (0:dt5:T)'    ; %时间层的节点剖分
plot(Tt1,Energy_BDF54_T10_dt1,'LineStyle','-.','Color','g','LineWidth',4)
hold on
plot(Tt2,Energy_BDF54_T10_dt05,'LineStyle','-','Color','b','LineWidth',4)
hold on
plot(Tt3,Energy_BDF54_T10_dt01,'Marker','none','Color','c','LineWidth',4)
hold on
plot(Tt4,Energy_BDF54_T10_dt005,'LineStyle',':','Color','m','LineWidth',4)
hold on
plot(Tt5,Energy_BDF54_T10_dt001,'LineStyle','--','Color','k','LineWidth',4)
xlabel('Time','FontSize',15); ylabel('Energy','fontsize',15); %y轴坐标值
axis auto 
set(gca,'FontName','Times New Roman','FontSize',15)
legend('BDF-DC_{5}^{4}, \Deltat=1','BDF-DC_{5}^{4}, \Deltat=1/2','BDF-DC_{5}^{4}, \Deltat=1/10','BDF-DC_{5}^{4}, \Deltat=1/20','BDF-DC_{5}^{4}, \Deltat=1/100','Location','NorthEast','fontsize',12)
%%
xlim([0 10]); ylim([147 155])
axes('position',[0.32,0.33,0.3,0.35]);
plot(Tt1,Energy_BDF54_T10_dt1,'LineStyle','-.','Color','g','LineWidth',4)
hold on
plot(Tt2,Energy_BDF54_T10_dt05,'LineStyle','-','Color','b','LineWidth',4)
hold on
plot(Tt3,Energy_BDF54_T10_dt01,'Marker','none','Color','c','LineWidth',4)
hold on
plot(Tt4,Energy_BDF54_T10_dt005,'LineStyle',':','Color','m','LineWidth',4)
hold on
plot(Tt5,Energy_BDF54_T10_dt001,'LineStyle','--','Color','k','LineWidth',4)
xlim([0 4]); ylim([147 155])

%%
%%
%BDF-DC54; S1 = 0; S2 = 0;
figure
load('Energy_DC54_T2_dt40.mat')
load('Energy_DC54_T2_dt50.mat')
load('Energy_DC54_T2_dt100.mat')

T = 2                       ; %终止时间
dt1 = 1/40              ; %时间剖分
Tt1 = (0:dt1:T)'    ; %时间层的节点剖分
dt2 = 1/50              ; %时间剖分
Tt2 = (0:dt2:T)'    ; %时间层的节点剖分
dt3 = 1/100             ; %时间剖分
Tt3 = (0:dt3:T)'    ; %时间层的节点剖分
plot(Tt1,Energy_DC54_T2_dt40,'LineStyle','-','Color','b','LineWidth',4)
hold on
plot(Tt2,Energy_DC54_T2_dt50,'LineStyle','-','Color','g','LineWidth',4)
hold on
plot(Tt3,Energy_DC54_T2_dt100,'LineStyle',':','Color','m','LineWidth',4)
xlabel('Time','FontSize',15); ylabel('Energy','fontsize',15); %y轴坐标值
axis auto 
set(gca,'FontName','Times New Roman','FontSize',15)
legend('BDF-DC_{5}^{4}, \Deltat=1/40','BDF-DC_{5}^{4}, \Deltat=1/50','BDF-DC_{5}^{4}, \Deltat=1/100','Location','NorthWest','fontsize',15)
xlim([0 2]); ylim([147 160])
