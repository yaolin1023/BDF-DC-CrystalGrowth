function Hm_grad = grad_Hm(phi_hat,N,L)
global sigma m theta0
%%构造FFT
kx = (2*pi/L)*[0:N/2-1 -N/2:-1]; ky = kx ; %频域坐标
[kX,kY] = meshgrid(kx,ky)                         ; %生成频域网格
KX = kX.^2; KY = kY.^2                               ; %Fourier谱加FFT   
et = reshape(phi_hat,N,N); Dxx = ifft2(-KX.*et); Dyy = ifft2(-KY.*et); Dx = ifft2(sqrt(-1)*kX.*et); Dy = ifft2(sqrt(-1)*kY.*et); Dxy = ifft2(-kX.*kY.*et); 
Dxx = real(Dxx); Dyy = real(Dyy); Dx = real(Dx); Dy = real(Dy); Dxy = real(Dxy); Dyx = Dxy; %Fourier谱加FFT
%%
%Fourier谱加FFT
theta        = atan2(Dy,Dx);  
Kappa        = 1+sigma*cos(m*(theta-theta0));
DKappa      =m*sigma*sin(m*(theta-theta0));
Kappa2      = Kappa.^2 ;
DxKappa2   = ifft2(sqrt(-1)*kX.*fft2(Kappa2)); DyKappa2 = ifft2(sqrt(-1)*kY.*fft2(Kappa2)); 
DxKappa2   = real(DxKappa2); DyKappa2 = real(DyKappa2);
DxyDKappa = ifft2(sqrt(-1)*kX.*fft2(Kappa.*DKappa.*Dy)); DyxDKappa = ifft2(sqrt(-1)*kY.*fft2(Kappa.*DKappa.*Dx)); 
DxyDKappa = real(DxyDKappa); DyxDKappa = real(DyxDKappa);
Hmxy       = Kappa2.*(Dxx + Dyy) + DxKappa2.*Dx + DyKappa2.*Dy + DxyDKappa - DyxDKappa;
Hm_grad = fft2(Hmxy); %二维FFT变换
Hm_grad = Hm_grad(:);

end
