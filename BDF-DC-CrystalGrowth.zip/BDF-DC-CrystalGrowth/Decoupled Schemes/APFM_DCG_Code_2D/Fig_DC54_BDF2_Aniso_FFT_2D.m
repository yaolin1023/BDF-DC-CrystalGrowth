clear all; close all;
tic
N =  128                                                      ; %空间剖分数目
L = 2*pi                                                     ; %空间剖分区间长度
global sigma  epsilon m theta0 lambda K
%节点坐标
%x = (L/N)*(0:N-1); y = x                          ; %空间剖分坐标
x   = (L/N)*(1/2:1:N-1/2); y = x               ;
hx = L/N; hy = hx                                        ; %空间步长
[X,Y] = meshgrid(x,y)                               ; %二维空间坐标
X1 = X(:); Y1 = Y(:)                                   ; %形成列向量
%构造FFT变换
kx = (2*pi/L)*[0:N/2-1 -N/2:-1]; ky = kx; %频域坐标
[kX,kY] = meshgrid(kx,ky)                       ; %生成频域网格
KX = kX.^2; KY = kY.^2                               ; 
K2 = kX.^2 + kY.^2                                     ; %二阶导数频域矩阵
K2 = K2(:)                                                 ; %矩阵向量化
%%
TT = [20, 30, 40, 50]; 
for jj = 1:length(TT)
%初始条件
% [phi_0, u_0] = u_exact(X, Y, 0)                                            ; %初始条件

% phi_0      = tanh( (1.5-sqrt((X-pi).^2+(Y-pi).^2))/0.1 )   ; %初始条件
% u_0          = -0.55*ones(N,N)                                                  ; %初始条件
% phi_0         = tanh( (0.25*pi - (X-pi).^2 - (Y-pi).^2)/0.1 )  ;
% u_0             = -0.5*phi_0                                                           ;

%phi_0        = tanh((6.924-sqrt(X.^2+Y.^2))/sqrt(2))          ; %初始条件
%phi_0        = tanh((0.02-sqrt((X-pi).^2+(Y-pi).^2))/0.072); %初始条件
%phi_0        = tanh((1.5-sqrt((X-pi).^2+(Y-pi).^2))/0.072); %初始条件
phi_0          = tanh( (2.7e-2-(X-pi).^2-(Y-pi).^2) / (5.4e-3) ); %初始条件
%phi_0        = tanh(sqrt(0.105-(X-pi).^2+(Y-pi).^2)/0.022); %不稳定初始条件
% phi_0        = tanh((0.02-sqrt((X-4*pi/5).^2+(Y-13*pi/10).^2))/0.072) +...
%                     tanh((0.02-sqrt((X-3*pi/4).^2+(Y-3*pi/4).^2))/0.072) +...
%                     tanh((0.02-sqrt((X-13*pi/10).^2+(Y-pi).^2))/0.072) + 2; %三个枝茎增长
PH = phi_0(:)                    ;
for j = 1:N^2
    if PH(j,1) > 0
        u(j,1)  = 0                ;
    else
        u(j,1)  = -0.55         ;
    end
end
u_0      = reshape(u,N,N)   ; 
phi0 = phi_0; u0 = u_0       ;
phi_0   = fft2(phi_0)        ; %二维FFT变换
u_0       = fft2(u_0)           ; 
phi_0   = phi_0(:)             ; 
u_0       = u_0(:)                ; 

% figure(1)
% % subplot(1,2,1)
% surf(X,Y,phi0)
% % hold on 
% % contourf(X,Y,phi0,[0 0])
% shading interp
% colormap jet
% colorbar
% view(0,90)
% axis([0 2*pi 0 2*pi])
% set(gca, 'XTick', [], 'YTick', [], 'ZTick', []) %Xlabel, Ylabel Zlabel
% 
% figure(2)
% % subplot(1,2,2)
% surf(X,Y,u0)
% % hold on 
% % contourf(X,Y,u0,[0 0])
% axis([0 2*pi 0 2*pi]); % axis square
% shading interp
% colormap jet
% colorbar
% view(0,90)
% axis([0 2*pi 0 2*pi])
% set(gca, 'XTick', [], 'YTick', [], 'ZTick', []) %Xlabel, Ylabel Zlabel

%数值求解
dt = 1/200   ; %时间步长
T  = TT(jj)  ; %终止时间
%epsilon = 1; lambda = 3.1913; D = 1; K = 0.5; sigma = 0.05; tau = 1                        ; %粘性系数
%tau = 1e2; epsilon = 0.1; lambda = 1; D = 2.25e-1; K = 1; sigma = 0.05                 ; %r0 = 1.5, 0.1
%tau = 1e3; epsilon = 0.1; lambda = 0.1; D = 5e-2; K = 0.01; sigma = 0.05              ;
%tau = 4.4e3; epsilon = 1.12e-2; lambda = 380; D = 2.25e-4 ; K = 0.7; sigma = 0.05; %r0 = 0.02
%tau = 100; epsilon = 0.06; lambda = 1; D = 1; K = 1; sigma = 0.05                           ;%r0 = 1.5, 0.072
tau = 6e2; epsilon = 1.5e-2; lambda = 3.6e2; D = 2.25e-3 ; K = 0.6; sigma = 0.04   ; %r0 = 2.7e-2
% D = 2.25e-4; tau = 1/D; epsilon = 1.12e-2; lambda = 355; K = 0.5; sigma = 0.05   ;%r0 = 0.105, 0.022 
S1  = 4; S2 = 4; m = 6; theta0 = pi/2                                                                           ; %稳定化参数
M   = round(T/dt)                                                                                                        ; %时间迭代数目
II   = ones(N^2,1)                                                                                                      ; %单位矩阵
Energy = zeros(M+1,1)                                                                                               ; %定义能量零矩阵
Energy_phi = zeros(M+1,1)                                                                                        ; %Crystal area
Energy(1) = hx*hy*( -0.5*sum(phi0(:).*m_grad(phi_0,N,L)) + lambda/(2*epsilon*K)*sum(u0(:).^2) +...
(1/(4*epsilon^2))*sum((phi0(:).^2-1).^2) )                                                          ; %初始能量
Energy_phi(1) = hx*hy*sum(1+phi0(:))/2; %Crystal area
%循环迭代
for k = 1:1 
Mphi = S1*(-K2) - (S2/epsilon^2)*II; Lu = D*(-K2);
AM = tau*II - (dt/2)*Mphi; AL = II - (dt/2)*Lu;
%------------[tn, tn+1/2]------第1步----------------%
BM = tau*phi_0 + (dt/2)*( G_phi_u(phi_0, phi0, u0, N, L) - Mphi.*phi_0 );
phi_1 = BM./AM;

phi1 = ifft2(reshape(phi_1,N,N)); phi1 = real(phi1); Fp = fft2(Fu(phi1).*(phi1-phi0)); %phi1 = min(max(phi1,-1),1);
BL = u_0 + 4*epsilon^2*K*Fp(:);
u_1 = BL./AL;

u1 = ifft2(reshape(u_1,N,N)); u1 = real(u1); 
%------------[tn+1/2, tn+1]----第2步-----------------%
BM = tau*phi_1 + (dt/2)*( G_phi_u(phi_1, phi1, u1, N, L) - Mphi.*phi_1 );
phi_2 = BM./AM;

phi2 = ifft2(reshape(phi_2,N,N)); phi2 = real(phi2); Fp = fft2(Fu(phi2).*(phi2-phi1)); %phi2 = min(max(phi2,-1),1);
BL = u_1 + 4*epsilon^2*K*Fp(:);
u_2 = BL./AL;

u2 = ifft2(reshape(u_2,N,N)); u2 = real(u2); 
%-------[tn, tn+1/2]-----第3步-----Correction-------%
BM = tau*phi_0 + (dt/2)*(-Mphi.*phi_1 + (1/2)*(G_phi_u(phi_0, phi0, u0, N, L) +  G_phi_u(phi_1, phi1, u1, N, L)));
phi_1 = BM./AM;

phi1 = ifft2(reshape(phi_1,N,N)); phi1 = real(phi1); %phi1 = min(max(phi1,-1),1); 
BL = u_0 + (dt/2)*(-Lu.*u_1 + (Lu/2).*(u_0 + u_1)) + IntF(phi1) - IntF(phi0)         ;
u_1 = BL./AL;

u1 = ifft2(reshape(u_1,N,N)); u1 = real(u1); 
%-------[tn+1/2, tn+1]-----第4步-----Correction-------%
BM = tau*phi_1 + (dt/2)*(-Mphi.*phi_2 + (1/2)*(G_phi_u(phi_1, phi1, u1, N, L) +  G_phi_u(phi_2, phi2, u2, N, L)));
phi_2 = BM./AM;

phi2 = ifft2(reshape(phi_2,N,N)); phi2 = real(phi2); %phi2 = min(max(phi2,-1),1); 
BL = u_1 + (dt/2)*(-Lu.*u_2 + (Lu/2).*(u_1 + u_2)) + IntF(phi2) - IntF(phi1)        ;
u_2 = BL./AL;

u2 = ifft2(reshape(u_2,N,N)); u2 = real(u2); 
%-------[tn, tn+1]-----第5步-----SDC_{5}^{3}-------%
AM = tau*II - dt*(1/3)*Mphi; AL = II - dt*(1/3)*Lu;
BM = tau*phi_0 + dt*((-1/3)*Mphi.*phi_2 + (1/6)*(G_phi_u(phi_0, phi0, u0, N, L) +4*G_phi_u(phi_1, phi1, u1, N, L) + G_phi_u(phi_2, phi2, u2, N, L)));
phi_4 = BM./AM;

phi4 = ifft2(reshape(phi_4,N,N)); phi4 = real(phi4); %phi4 = min(max(phi4,-1),1);
BL = u_0 + dt*((-1/3)*Lu.*u_2 + (Lu/6).*(u_0 + 4*u_1 + u_2)) + IntF(phi4) - IntF(phi0);
u_4 = BL./AL;

u4 = ifft2(reshape(u_4,N,N)); u4 = real(u4);
%-------[tn, tn+1/2]-----第6步-----SDC_{5}^{3}-------%
AM = tau*II - dt*(2/3)*Mphi; AL = II - dt*(2/3)*Lu;
BM = tau*phi_0 + dt*((-2/3)*Mphi.*phi_1 + (1/24)*(5*G_phi_u(phi_0, phi0, u0, N, L) +8*G_phi_u(phi_1, phi1, u1, N, L) - G_phi_u(phi_2, phi2, u2, N, L)));
phi_3 = BM./AM;

phi3 = ifft2(reshape(phi_3,N,N)); phi3 = real(phi3); %phi3 = min(max(phi3,-1),1);
BL = u_0 + dt*((-2/3)*Lu.*u_1 + (Lu/24).*(5*u_0 + 8*u_1 - u_2)) + IntF(phi3) - IntF(phi0);
u_3 = BL./AL;

u3 = ifft2(reshape(u_3,N,N)); u3 = real(u3);
%-------[tn, tn+1]-----第7步-----SDC_{7}^{4}-------%
AM = tau*II - dt*(1/3)*Mphi; AL = II - dt*(1/3)*Lu;
BM = tau*phi_0 + dt*((-1/3)*Mphi.*phi_4 + (1/6)*(G_phi_u(phi_0, phi0, u0, N, L) + 4*G_phi_u(phi_3, phi3, u3, N, L) + G_phi_u(phi_4, phi4, u4, N, L)));
phi_4 = BM./AM;

phi4 = ifft2(reshape(phi_4,N,N)); phi4 = real(phi4); %phi4 = min(max(phi4,-1),1);
BL = u_0 + dt*((-1/3)*Lu.*u_4 + (Lu/6).*(u_0 + 4*u_3 + u_4)) + IntF(phi4) - IntF(phi0);
u_4 = BL./AL;
u4 = ifft2(reshape(u_4,N,N)); u4 = real(u4);

%phi_2 = phi_4; u_2 = u_4; phi2 = phi4; u2 = u4;
%phi_0 = phi_2; u_0 = u_2; phi0 = phi2; u0 = u2;

phi_1 = phi_4; u_1 = u_4; phi1 = phi4; u1 = u4;

Energy(2) = hx*hy*( -0.5*sum(phi1(:).*m_grad(phi_1,N,L)) + lambda/(2*epsilon*K)*sum(u1(:).^2) +...
(1/(4*epsilon^2))*sum((phi1(:).^2-1).^2) )                                                    ; %初始能量
Energy_phi(2) = hx*hy*sum(1+phi1(:))/2; %Crystal area
end

%%循环迭代
for k = 2:M
Mphi = S1*(-K2) - (S2/epsilon^2)*II; Lu = D*(-K2);
%------------[tn, tn+1/2]------第1步---BDF2-------------%
phi_bar = (3/2)*phi_1 - (1/2)*phi_0; %u_bar = (3/2)*u_1 - (1/2)*u_0;
phibar = (3/2)*phi1 - (1/2)*phi0; ubar = (3/2)*u1 - (1/2)*u0;
AM = tau*II - (3*dt/8)*Mphi; AL = II - (3*dt/8)*Lu;
BM = (-tau/8)*phi_0 + (9*tau/8)*phi_1 + (3*dt/8)*( G_phi_u(phi_bar, phibar, ubar, N, L) - Mphi.*phi_bar );
phi_3 = BM./AM;

phi3 = ifft2(reshape(phi_3,N,N)); phi3 = real(phi3); %phi3 = min(max(phi3,-1),1); 
Fp = fft2(Fu(phi3).*(phi3 - (9/8)*phi1 + (1/8)*phi0));
BL = (-1/8)*u_0 + (9/8)*u_1 + 4*epsilon^2*K*Fp(:);
u_3 = BL./AL;

u3 = ifft2(reshape(u_3,N,N)); u3 = real(u3);            
%------------[tn, tn+1]----第2步------BDF2------------%
phi_bar = 2*phi_1 - phi_0; %u_bar = 2*u_1 - u_0;
phibar = 2*phi1 - phi0; ubar = 2*u1 - u0;
AM = tau*II - (2*dt/3)*Mphi; AL = II - (2*dt/3)*Lu;
BM = (-tau/3)*phi_0 + (4*tau/3)*phi_1 + (2*dt/3)*( G_phi_u(phi_bar, phibar, ubar, N, L) - Mphi.*phi_bar );
phi_4 = BM./AM;

phi4 = ifft2(reshape(phi_4,N,N)); phi4 = real(phi4); %phi4 = min(max(phi4,-1),1); 
Fp = fft2(Fu(phi4).*(phi4 - (4/3)*phi1 + (1/3)*phi0));
BL = (-1/3)*u_0 + (4/3)*u_1 + 4*epsilon^2*K*Fp(:);
u_4 = BL./AL;

u4 = ifft2(reshape(u_4,N,N)); u4 = real(u4);  
%-------[tn, tn+1]-----第3步-----BDF-DC_{3}^{3}-------%
AM = tau*II - dt*(1/2)*Mphi; AL = II - dt*(1/2)*Lu;
BM = tau*phi_1 + dt*((-1/2)*Mphi.*phi_4 + (1/6)*(G_phi_u(phi_1, phi1, u1, N, L) +...
4*G_phi_u(phi_3, phi3, u3, N, L) + G_phi_u(phi_4, phi4, u4, N, L)));
phi_6 = BM./AM;

phi6 = ifft2(reshape(phi_6,N,N)); phi6 = real(phi6); %phi6 = min(max(phi6,-1),1);
BL = u_1 + dt*((-1/2)*Lu.*u_4 + (Lu/6).*(u_1 + 4*u_3 + u_4)) + IntF(phi6) - IntF(phi1);
u_6 = BL./AL;

u6 = ifft2(reshape(u_6,N,N)); u6 = real(u6);
%-------[tn, tn+1/2]-----第4步-----BDF-DC_{4}^{3}-------%
AM = tau*II - dt*(1/2)*Mphi; AL = II - dt*(1/2)*Lu;
BM = tau*phi_1 + dt*((-1/2)*Mphi.*phi_3 + (1/24)*(5*G_phi_u(phi_1, phi1, u1, N, L) +...
8*G_phi_u(phi_3, phi3, u3, N, L) - G_phi_u(phi_4, phi4, u4, N, L)));
phi_5 = BM./AM;

phi5 = ifft2(reshape(phi_5,N,N)); phi5 = real(phi5); %phi5 = min(max(phi5,-1),1);
BL = u_1 + dt*((-1/2)*Lu.*u_3 + (Lu/24).*(5*u_1 + 8*u_3 - u_4)) + IntF(phi5) - IntF(phi1);
u_5 = BL./AL;

u5 = ifft2(reshape(u_5,N,N)); u5 = real(u5);
%-------[tn, tn+1]-----第5步-----SDC_{5}^{4}-------%
AM = tau*II - dt*(1/2)*Mphi; AL = II - dt*(1/2)*Lu;
BM = tau*phi_1 + dt*((-1/2)*Mphi.*phi_6 + (1/6)*(G_phi_u(phi_1, phi1, u1, N, L) +...
4*G_phi_u(phi_5, phi5, u5, N, L) + G_phi_u(phi_6, phi6, u6, N, L)));
phi_6 = BM./AM;

phi6 = ifft2(reshape(phi_6,N,N)); phi6 = real(phi6); %phi6 = min(max(phi6,-1),1);
BL = u_1 + dt*((-1/2)*Lu.*u_6 + (Lu/6).*(u_1 + 4*u_5 + u_6)) + IntF(phi6) - IntF(phi1);
u_6 = BL./AL;
u6 = ifft2(reshape(u_6,N,N)); u6 = real(u6);

phi_2 = phi_6; u_2 = u_6; phi2 = phi6; u2 = u6;

phi_0 = phi_1; phi_1 = phi_2; u_0 = u_1; u_1 = u_2; 
phi0 = phi1; phi1 = phi2; u0 = u1; u1 = u2;

Energy(k+1) = hx*hy*( -0.5*sum(phi2(:).*m_grad(phi_2,N,L)) + lambda/(2*epsilon*K)*sum(u2(:).^2) +...
(1/(4*epsilon^2))*sum((phi2(:).^2-1).^2) )                                                    ; %初始能量
Energy_phi(k+1) = hx*hy*sum(1+phi2(:))/2; %Crystal area
end

phi_h = phi2(:); u_h = u2(:); Energy = real(Energy); %选取能量的实数部分
format short e
% figure(10)
% Tt = (0:dt:T)'                                                                                                      ; %时间层的节点剖分
% plot(Tt,Energy,'-b')
% xlabel('Time','fontsize',10); ylabel('Energy','fontsize',10)                    ; %y轴坐标值
% title('alpah=1','fontsize',10); %标题显示

figure
% subplot(1,2,1)
surf(X,Y,phi2)
% hold on 
% contourf(X,Y,phi2,[pi pi])
shading interp
colormap jet
colorbar
view(0,90)
axis([0 2*pi 0 2*pi])
set(gca, 'XTick', [], 'YTick', [], 'ZTick', []) %Xlabel, Ylabel Zlabel

figure
% subplot(1,2,2)
surf(X,Y,u2)
% hold on 
% contourf(X,Y,u2,[0 0])
axis([0 2*pi 0 2*pi]); % axis square
shading interp
colormap jet
colorbar
view(0,90)
axis([0 2*pi 0 2*pi])
set(gca, 'XTick', [], 'YTick', [], 'ZTick', []) %Xlabel, Ylabel Zlabel

end

toc