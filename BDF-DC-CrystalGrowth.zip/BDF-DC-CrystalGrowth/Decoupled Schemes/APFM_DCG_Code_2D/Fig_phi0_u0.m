clear all; close all;
tic
N = 512  ; %空间剖分数目
L = 2*pi ; %空间剖分区间长度
% global tau epsilon lambda D K sigma
%节点坐标
x = (L/N)*(0:N-1); y = x; %空间剖分坐标
hx = L/N; hy = hx       ; %空间步长
[X,Y] = meshgrid(x,y)   ; %二维空间坐标
X1 = X(:); Y1 = Y(:)    ; %形成列向量

%初始条件
% [phi_0, u_0] = u_exact(X, Y, 0); %初始条件
% phi_0        = tanh((1.5-sqrt((X-pi).^2+(Y-pi).^2))/0.1); %初始条件
% u_0          = -0.55*ones(N,N) ; %初始条件
phi_0        = tanh((0.02-sqrt((X1-pi).^2+(Y1-pi).^2))/(0.072)); %初始条件
%phi_0        = tanh((1.5-sqrt((X-pi).^2+(Y-pi).^2))/0.072); %初始条件
PHI0 = phi_0(:);
for j = 1:N^2
    if PHI0(j,1) > 0
        u_0(j,1) = -0.55;
    else
        u_0(j,1) = 0;
    end
end
phi_h = phi_0(:); u_h = u_0(:);

% phi_0        = tanh((6.924-sqrt(X.^2+Y.^2))/sqrt(2)); %初始条件
% PHI = reshape(phi_0,N^2,1)                          ; %初始条件
% for j = 1:N^2
%     if PHI(j,1) > 0
%         u_0(j,1)  = 0       ;
%     else
%         u_0(j,1)  = -0.55   ;
%     end
% end
% u_0 = reshape(u,N,N)      ;
phi_h = phi_0; u_h = u_0    ;
figure(1)
%画图
% phi_num = zeros(N+1,N+1);
% x1 = (L/N)*(0:N); y1 = x1  ; %空间剖分坐标
% [X2,Y2] = meshgrid(x1,y1)  ; %二维空间坐标
% phi_h = reshape(phi_h,N,N) ; %向量转换成矩阵
% phi_num(1:N,1:N) = phi_h(1:N,1:N);phi_num(N+1,1:N) = phi_h(1,1:N); phi_num(1:N,N+1) = phi_h(1:N,1); phi_num(N+1,N+1) = phi_h(1,1);
surf(X,Y,reshape(phi_h,N,N)); %axis([0 7 0 7])
shading interp
colormap jet; colorbar

figure(2)
%画图
% u_num = zeros(N+1,N+1);
% x2 = (L/N)*(0:N); y2 = x2         ; %空间剖分坐标
% [X3,Y3] = meshgrid(x2,y2)         ; %二维空间坐标
% u_h = reshape(u_h,N,N)            ; %向量转换成矩阵
% u_num(1:N,1:N) = u_h(1:N,1:N);u_num(N+1,1:N) = u_h(1,1:N); u_num(1:N,N+1) = u_h(1:N,1); u_num(N+1,N+1) = u_h(1,1);
surf(X,Y,reshape(u_h,N,N));
%axis([-0.5 0.5 -0.5 0.5])
shading interp
colormap jet; colorbar

toc

% u_0 = reshape(u,N,N);
% phi_0        = phi_0(:)        ; %矩阵向量化
% u_0          = u_0(:)          ; %矩阵向量化
% tau = 4.4e3; epsilon = 1.12e-2; lambda = 380; D = 2.25e-4; K = 1; sigma = 0.05; %粘性系数
% S1  = 4; S2 = 4                                            ; %稳定化参数
% PHI = reshape(phi_0,N^2,1);