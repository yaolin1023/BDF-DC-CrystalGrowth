clear all; close all;

%%
%BDF-DC54-2D; beta = 4;
figure

 load('Energy_DC54_K06_T160_2D.mat')
 load('Energy_DC54_K07_T160_2D.mat')
 load('Energy_DC54_K09_T160_2D.mat')
T = 160                    ; %终止时间
dt1 = 1/100             ; %时间剖分
Tt1 = (0:dt1:T)'    ; %时间层的节点剖分
dt2 = 1/100             ; %时间剖分
Tt2 = (0:dt2:T)'    ; %时间层的节点剖分
dt3 = 1/100             ; %时间剖分
Tt3 = (0:dt3:T)'    ; %时间层的节点剖分
plot(Tt1,Energy_DC54_K06_T160_2D,'LineStyle','-','Color','b','LineWidth',4)
hold on
plot(Tt2,Energy_DC54_K07_T160_2D,'LineStyle','-','Color','g','LineWidth',4)
hold on
plot(Tt3,Energy_DC54_K09_T160_2D,'LineStyle','-','Color','m','LineWidth',4)
xlabel('Time','FontSize',15); ylabel('Energy','fontsize',15); %y轴坐标值
axis auto 
set(gca,'FontName','Times New Roman','FontSize',15)
legend('BDF-DC_{5}^{4}, K=0.6','BDF-DC_{5}^{4}, K=0.7','BDF-DC_{5}^{4}, K=0.9','Location','NorthEast','fontsize',15)

%%
%BDF-DC54-2D; beta = 4;
figure

load('Energy_phi_DC54_K06_T160_2D.mat')
load('Energy_phi_DC54_K07_T160_2D.mat')
load('Energy_phi_DC54_K09_T160_2D.mat')
T = 160                    ; %终止时间
dt1 = 1/100             ; %时间剖分
Tt1 = (0:dt1:T)'    ; %时间层的节点剖分
dt2 = 1/100             ; %时间剖分
Tt2 = (0:dt2:T)'    ; %时间层的节点剖分
dt3 = 1/100             ; %时间剖分
Tt3 = (0:dt3:T)'    ; %时间层的节点剖分
plot(Tt1,Energy_phi_DC54_K06_T160_2D,'LineStyle','-','Color','b','LineWidth',4)
hold on
plot(Tt2,Energy_phi_DC54_K07_T160_2D,'LineStyle','-','Color','g','LineWidth',4)
hold on
plot(Tt3,Energy_phi_DC54_K09_T160_2D,'LineStyle','-','Color','m','LineWidth',4)
xlabel('Time','FontSize',15); ylabel('Crystal area','fontsize',15); %y轴坐标值
axis auto 
set(gca,'FontName','Times New Roman','FontSize',15)
legend('BDF-DC_{5}^{4}, K=0.6','BDF-DC_{5}^{4}, K=0.7','BDF-DC_{5}^{4}, K=0.9','Location','NorthWest','fontsize',15)

%%
%BDF-DC54-2D; beta=6;
figure

load('Energy_DC54_m6_K06_T40_2D.mat')
load('Energy_DC54_m6_K07_T40_2D.mat')
load('Energy_DC54_m6_K09_T40_2D.mat')
T = 40                      ; %终止时间
dt1 = 1/100             ; %时间剖分
Tt1 = (0:dt1:T)'    ; %时间层的节点剖分
dt2 = 1/100             ; %时间剖分
Tt2 = (0:dt2:T)'    ; %时间层的节点剖分
dt3 = 1/100             ; %时间剖分
Tt3 = (0:dt3:T)'    ; %时间层的节点剖分
plot(Tt1,Energy_DC54_m6_K06_T40_2D,'LineStyle','-','Color','b','LineWidth',4)
hold on
plot(Tt2,Energy_DC54_m6_K07_T40_2D,'LineStyle','-','Color','g','LineWidth',4)
hold on
plot(Tt3,Energy_DC54_m6_K09_T40_2D,'LineStyle','-','Color','m','LineWidth',4)
xlabel('Time','FontSize',15); ylabel('Crystal area','fontsize',15); %y轴坐标值
axis auto 
set(gca,'FontName','Times New Roman','FontSize',15)
legend('BDF-DC_{5}^{4}, K=0.6','BDF-DC_{5}^{4}, K=0.7','BDF-DC_{5}^{4}, K=0.9','Location','NorthEast','fontsize',15)


%%
%BDF-DC54-2D; beta=6;
figure

load('Energy_DC54_phi_m6_K06_T40_2D.mat')
load('Energy_DC54_phi_m6_K07_T40_2D.mat')
load('Energy_DC54_phi_m6_K09_T40_2D.mat')
T = 40                      ; %终止时间
dt1 = 1/100             ; %时间剖分
Tt1 = (0:dt1:T)'    ; %时间层的节点剖分
dt2 = 1/100             ; %时间剖分
Tt2 = (0:dt2:T)'    ; %时间层的节点剖分
dt3 = 1/100             ; %时间剖分
Tt3 = (0:dt3:T)'    ; %时间层的节点剖分
plot(Tt1,Energy_DC54_phi_m6_K06_T40_2D,'LineStyle','-','Color','b','LineWidth',4)
hold on
plot(Tt2,Energy_DC54_phi_m6_K07_T40_2D,'LineStyle','-','Color','g','LineWidth',4)
hold on
plot(Tt3,Energy_DC54_phi_m6_K09_T40_2D,'LineStyle','-','Color','m','LineWidth',4)
xlabel('Time','FontSize',15); ylabel('Crystal area','fontsize',15); %y轴坐标值
axis auto 
set(gca,'FontName','Times New Roman','FontSize',15)
legend('BDF-DC_{5}^{4}, K=0.6','BDF-DC_{5}^{4}, K=0.7','BDF-DC_{5}^{4}, K=0.9','Location','NorthWest','fontsize',15)



