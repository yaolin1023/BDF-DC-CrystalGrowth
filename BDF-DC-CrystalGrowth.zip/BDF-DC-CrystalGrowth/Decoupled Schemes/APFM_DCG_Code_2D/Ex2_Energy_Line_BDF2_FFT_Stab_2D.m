clear all; close all;
tic
N = 128                         ; %空间剖分数目
L = 2*pi                         ; %空间剖分区间长度
global sigma  epsilon m theta0
%节点坐标
%x = (L/N)*(0:N-1); y = x; %空间剖分坐标
x   = (L/N)*(1/2:1:N-1/2); y = x;
hx = L/N; hy = hx            ; %空间步长
[X,Y] = meshgrid(x,y)   ; %二维空间坐标
X1 = X(:); Y1 = Y(:)       ; %形成列向量
%构造FFT变换
kx = (2*pi/L)*[0:N/2-1 -N/2:-1]; ky = kx; %频域坐标
[kX,kY] = meshgrid(kx,ky)                       ; %生成频域网格
K2 = kX.^2 + kY.^2                                     ; %二阶导数频域矩阵
K2 = K2(:)                                                  ; %矩阵向量化
%初始条件
phi_0      = tanh((1.5-sqrt((X-pi).^2+(Y-pi).^2))/0.1); %初始条件
u_0          = -0.55*ones(N,N)                                             ; %初始条件
phi0 = phi_0; u0 = u_0      ;
phi_0        = fft2(phi_0)  ; %二维FFT变换
u_0          = fft2(u_0)       ; %二维FFT变换
phi_0        = phi_0(:)       ; %矩阵向量化
u_0          = u_0(:)            ; %矩阵向量化

%数值求解
dt = 1/1                            ; %时间步长
T  = 10                              ; %终止时间

tau = 1e2; epsilon = 0.1; lambda = 1; D = 2.25e-1; K = 1; sigma = 0.05   ; 
S1  = 4; S2 = 4; m = 4; theta0 = 0                                                               ; %稳定化参数
M   = round(T/dt)                                                                                       ; %时间迭代数目
II   = ones(N^2,1)                                                                                     ; %单位矩阵
Energy = zeros(M+1,1)                                                                              ; %定义能量零矩阵
Energy(1) = hx*hy*( -0.5*sum(phi0(:).*m_grad(phi_0,N,L)) + lambda/(2*epsilon*K)*sum(u0(:).^2) +...
(1/(4*epsilon^2))*sum((phi0(:).^2-1).^2) ); %初始能量
%%%----BDF1--[t0, t1]-----------------%%%
for k = 1:1
fu = fft2(dFu(phi0)); FU = fft2(Fu(phi0).*u0)   ; 
A = tau*II - S1*dt*(-K2) + (S2/epsilon^2)*dt*II; %phi
B = tau*phi_0 + dt*grad_Hm(phi_0,N,L) - S1*dt*(-K2).*phi_0 + (S2/epsilon^2)*dt*phi_0 -...
dt*fu(:) - 4*lambda*epsilon*dt*FU(:)                 ;
phi_1 = B./A                                                            ;
% 
phi1 = ifft2(reshape(phi_1,N,N)); phi1 = real(phi1); Fp = fft2(Fu(phi1).*(phi1-phi0)); 
A = II - D*dt*(-K2)                  ; %u
B = u_0 + 4*epsilon^2*K*Fp(:);
u_1 = B./A                                ;
%phi_0 = phi_1; u_0 = u_1        ; phi0 = phi1; u0 = u1;
u1 = ifft2(reshape(u_1,N,N)); u1 = real(u1); 
end
Energy(2) = hx*hy*( -0.5*sum(phi1(:).*m_grad(phi_1,N,L)) + lambda/(2*epsilon*K)*sum(u1(:).^2) +...
(1/(4*epsilon^2))*sum((phi1(:).^2-1).^2) ); %初始能量
%%
%%%----BDF2--[tn, tn+1]-----------------%%%
for k = 2:M
phi_bar = 2*phi_1 - phi_0; u_bar = 2*u_1 - u_0; phiEx = 2*phi1 - phi0; uEx = 2*u1 - u0; 
fu = fft2(dFu(phiEx)); FU = fft2(Fu(phiEx).*uEx)      ; 
A = (3*tau/(2*dt))*II - S1*(-K2) + (S2/epsilon^2)*II; %phi
B = (tau/(2*dt))*(4*phi_1 - phi_0) + grad_Hm(phi_bar,N,L) - S1*(-K2).*phi_bar + (S2/epsilon^2)*phi_bar - fu(:) - 4*lambda*epsilon*FU(:);
phi_2 = B./A                                                                   ;

phi2 = ifft2(reshape(phi_2,N,N)); phi2 = real(phi2); Fp = fft2(Fu(phi2).*(3*phi2-4*phi1+phi0)); 
A = (3/(2*dt))*II - D*(-K2)                                          ; %u
B = (1/(2*dt))*(4*u_1 - u_0) + (1/(2*dt))*4*epsilon^2*K*Fp(:);
u_2 = B./A                                                                       ;

%Energy
u2 = ifft2(reshape(u_2,N,N)); u2 = real(u2)          ; 
phi_0 = phi_1; phi_1 = phi_2; u_0 = u_1; u_1 = u_2  ;
phi0 = phi1; phi1 = phi2; u0 = u1; u1 = u2                ;
Energy(k+1) = hx*hy*( -0.5*sum(phi2(:).*m_grad(phi_2,N,L)) + lambda/(2*epsilon*K)*sum(u2(:).^2) +...
(1/(4*epsilon^2))*sum((phi2(:).^2-1).^2) )         ; %初始能量
end
%%
phi_h = phi2(:); u_h = u2(:); Energy = real(Energy) ; %选取能量的实数部分

format short e
figure
Tt = (0:dt:T)'                                                            ; %时间层的节点剖分
plot(Tt,Energy,'-b')
xlabel('Time','fontsize',10); ylabel('Energy','fontsize',10); %y轴坐标值

toc