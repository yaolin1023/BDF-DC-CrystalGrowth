function Int = IntF(phi)
global K 

F_int = K*((1/5)*phi.^5-(2/3)*phi.^3+phi);
Fp = fft2(F_int); Int = Fp(:);



