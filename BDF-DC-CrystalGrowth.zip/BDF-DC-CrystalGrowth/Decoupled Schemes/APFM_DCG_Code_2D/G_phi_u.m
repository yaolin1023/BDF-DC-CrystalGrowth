function Gphinu = G_phi_u(phi_0, phi0, u0, N, L)

global lambda epsilon 

fu = fft2(dFu(phi0)); FU = fft2(Fu(phi0).*u0);
Gphinu = grad_Hm(phi_0,N,L) - fu(:) - 4*lambda*epsilon*FU(:); %各项异性

end