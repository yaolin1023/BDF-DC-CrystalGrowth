clear all; close all;
tic
N = 128   ; %空间剖分数目
L = 2*pi ; %空间剖分区间长度
global tau epsilon lambda D K sigma m theta0
%节点坐标
%x = (L/N)*(0:N-1); y = x; %空间剖分坐标
x        = (L/N)*(1/2:1:N-1/2); y = x;
hx      = L/N; hy = hx               ; %空间步长
[X,Y] = meshgrid(x,y)           ; %二维空间坐标
X1      = X(:); Y1 = Y(:)          ; %形成列向量
%构造FFT变换
kx = (2*pi/L)*[0:N/2-1 -N/2:-1]; ky = kx; %频域坐标
[kX,kY] = meshgrid(kx,ky)                       ; %生成频域网格
KX = kX.^2; KY = kY.^2                               ; 
K2 = kX.^2 + kY.^2                                     ; %二阶导数频域矩阵
K2 = K2(:)                                                  ; %矩阵向量化
%数值求解
Tau = [1/20 1/40 1/80 1/160 1/320 1/640] ;  
for i = 1:length(Tau)
%初始条件
[phi_0, u_0] = u_exact(X, Y, 0); %初始条件
phi0 = phi_0; u0 = u_0                ;
phi_0        = fft2(phi_0)            ; %二维FFT变换
u_0          = fft2(u_0)                 ; %二维FFT变换
phi_0        = phi_0(:)                 ; %矩阵向量化
u_0          = u_0(:)                      ; %矩阵向量化
%数值求解
dt  = Tau(i)                              ; %时间步长 32768
T   = 1                                        ; %终止时间
tau = 4e3; epsilon = 1; lambda = 1; D = 1; K = 0.01; sigma = 0.05; %粘性系数
S1  = 4; S2 = 4; m = 4; theta0 = 0                                                   ; %稳定化参数
M   = round(T/dt)                                                                           ; %时间迭代数目
II   = ones(N^2,1)                                                                         ; %单位矩阵

%%%----BDF1--[t0, t1]-----------------%%%
for k = 1:1
fu = fft2(dFu(phi0)); FU = fft2(Fu(phi0).*u0)   ; 
A = tau*II - S1*dt*(-K2) + (S2/epsilon^2)*dt*II; %phi
B = tau*phi_0 + dt*grad_Hm(phi_0,N,L) - S1*dt*(-K2).*phi_0 + (S2/epsilon^2)*dt*phi_0 - dt*fu(:) - 4*lambda*epsilon*dt*FU(:);                 
phi_1 = B./A                                                           ;
% 
phi1 = ifft2(reshape(phi_1,N,N)); phi1 = real(phi1); Fp = fft2(Fu(phi1).*(phi1-phi0)); 
A = II - D*dt*(-K2)                  ; %u
B = u_0 + 4*epsilon^2*K*Fp(:);
u_1 = B./A                                ;
u1 = ifft2(reshape(u_1,N,N)); u1 = real(u1);

%phi_0 = phi_1; u_0 = u_1        ; phi0 = phi1; u0 = u1;
%PHI(:,i) = phi1(:); U(:,i) = u1(:);
end
%%%----BDF2--[tn, tn+1]-----------------%%%
for k = 2:M
phi_bar = 2*phi_1 - phi_0; u_bar = 2*u_1 - u_0; phiEx = 2*phi1 - phi0; uEx = 2*u1 - u0; 
fu = fft2(dFu(phiEx)); FU = fft2(Fu(phiEx).*uEx); 

A = (3*tau/(2*dt))*II - S1*(-K2) + (S2/epsilon^2)*II; %phi
B = (tau/(2*dt))*(4*phi_1 - phi_0) + grad_Hm(phi_bar,N,L) - S1*(-K2).*phi_bar + (S2/epsilon^2)*phi_bar - fu(:) - 4*lambda*epsilon*FU(:); 
phi_2 = B./A;

phi2 = ifft2(reshape(phi_2,N,N)); phi2 = real(phi2); 
Fp = fft2(Fu(phi2).*(3*phi2-4*phi1+phi0)); 
A = (3/(2*dt))*II - D*(-K2); %u
B = (1/(2*dt))*(4*u_1 - u_0) + (1/(2*dt))*4*epsilon^2*K*Fp(:); 
u_2 = B./A                 ;
u2 = ifft2(reshape(u_2,N,N)); u2 = real(u2);

phi_0 = phi_1; phi_1 = phi_2; u_0 = u_1; u_1 = u_2;
phi0 = phi1; phi1 = phi2; u0 = u1; u1 = u2;
end
phi_h = phi2(:); u_h = u2(:);

PHI(:,i) = phi_h; U(:,i) = u_h;
end

format short e

for j = 1:length(Tau) - 1

L_2_error_phi(j,1) = sqrt(sum((abs(PHI(:,j) - PHI(:,j+1))).^2))/N; 
L_2_error_u(j,1) = sqrt(sum((abs(U(:,j) - U(:,j+1))).^2))/N          ; 

end
for j = 1:length(L_2_error_phi) - 1
    Rate_phi(j,1) = log2( L_2_error_phi(j) / L_2_error_phi(j+1) );
    Rate_u(j,1) = log2( L_2_error_u(j) / L_2_error_u(j+1) )           ;

end
L_2_error_phi
L_2_error_u

Rate_phi
Rate_u

toc
