function grad_m = m_grad(phi,N,L)
%计算grad*(grad(m) + grad(H))
global sigma m theta0

%构造一阶谱求导矩阵
% h = 2*pi/N; column1 = [0 0.5*(-1).^(1:N-1).*cot((1:N-1)*h/2)]'; 
% Ex = (2*pi/L)*toeplitz(column1,column1([1 N:-1:2]))                 ; %一阶谱求导矩阵
% Ey = Ex                                                                                              ;
% %构造二阶谱求导矩阵
% h = 2*pi/N; column = [-pi^2/(3*h^2)-1/6 -0.5*(-1).^(1:N-1)./sin((1:N-1)*h/2).^2]; %构造二阶谱求导列矩阵
% Kx = (2*pi/L)^2*toeplitz(column); %构造一维求导矩阵
% Ky = Kx                                            ;

%构造有限差分格式
%hx = L/N;
[~, ~, ~, ~,~,~, Ex, Ey, Kx, Ky, ~] = Finite_difference_matrix_2D(N);

%[Dx, Dy, Dxx, Dyy,Dxy,~, ~, ~, ~, ~, ~] = Finite_difference_matrix_2D(N);

%----------------守恒型形式----------------%
Phin = reshape(phi,N,N);
DxPhin=Phin*Ex';
DyPhin=Ey*Phin;
DxxPhin=Phin*Kx';
DyyPhin=Ky*Phin;
theta=atan2(DyPhin,DxPhin);
Kappa=1+sigma*cos(m*(theta-theta0));
%Kappa=1+(1/(m^2-1))*cos(m*(theta-theta0));
Kappa2=Kappa.^2 ;
Mmxy = Kappa2.*(DxxPhin + DyyPhin) + (Kappa2*Ex').*DxPhin + (Ey*Kappa2).*DyPhin;
grad_m = Mmxy(:);

%Mmx = Phin.*( Kappa2.*DxxPhin + (Kappa2*Ex').*DxPhin ); Mmy = Phin.*( Kappa2.*DyyPhin + (Ey*Kappa2).*DyPhin );
%grad_m = Mmx(:) + Mmy(:);

%---------------非守恒形式-----------------%
%---------------------二维非守恒型模型------------------%
% Phin = reshape(phi,N,N); Dx=Phin*Ex'; Dy=Ey*Phin; Dxx=Phin*Kx';
% Dyy=Ky*Phin; Dxy = (Ey*Phin)*Ex'; 
% %Dx = Dx*phi; Dy = Dy*phi; Dxx = Dxx*phi; Dyy = Dyy*phi; Dxy = Dxy*phi;
% theta      = atan2(Dy,Dx)                              ;  
% Kappa      = 1+sigma*cos(m*(theta-theta0)); 
% DKappa    = m*sigma*sin(m*(theta-theta0));
% Kappa2    = Kappa.^2                                     ;
% mxy         = Kappa2.*(Dxx + Dyy) - 2*Kappa.*DKappa.*(cos(2*theta).*Dxy + (1/2)*sin(2*theta).*(Dyy - Dxx)); %完全展开
% %mxy         = (1+sigma^2/2+2*sigma*cos(m*(theta-theta0)) + (sigma^2/2)*cos(2*m*(theta-theta0))).*(Dxx + Dyy) - (2*sigma*m*sin(m*(theta-theta0)) + m*sigma^2*sin(2*m*(theta-theta0))).*(cos(2*theta).*Dxy + (1/2)*sin(2*theta).*(Dyy - Dxx));
% grad_m    = mxy(:)                                         ;


end





%构造一阶谱求导矩阵
% h = 2*pi/N; column1 = [0 0.5*(-1).^(1:N-1).*cot((1:N-1)*h/2)]'; 
% D1 = (2*pi/L)*toeplitz(column1,column1([1 N:-1:2])); %一阶谱求导矩阵
% I = speye(N); Dx = kron(D1,I); Dy = kron(I,D1); %一阶谱求导矩阵x方向和y方向
%构造二阶谱求导矩阵
% h = 2*pi/N; column = [-pi^2/(3*h^2)-1/6 -0.5*(-1).^(1:N-1)./sin((1:N-1)*h/2).^2]; %构造二阶谱求导列矩阵
% D2 = (2*pi/L)^2*toeplitz(column)                  ; %构造一维求导矩阵
% I = speye(N); Dxx = kron(D2,I); Dyy = kron(I,D2)  ; %构造二维谱求导矩阵

% %构造有限差分矩阵
% [Dx, Dy, ~, ~, ~] = Finite_difference_matrix_2D(N); 

% m_grad = (((1+sigma)*(Dy*phi).^4+(2-6*sigma)*(Dy*phi).^2.*(Dx*phi).^2+(1+sigma)*(Dx*phi).^4).^2)./( ((Dy*phi).^2+(Dx*phi).^2).^3 ); %+10^(-10)
%end

%mxy = 2*(Dx*phi).*(Dxx*phi) + 2*(Dy*phi).*(Dyy*phi) + (Dx*Dy*phi).*(2*(Dx*phi) + 2*(Dy*phi)); grad_m = (Dxx+Dyy)*phi +  mxy;
