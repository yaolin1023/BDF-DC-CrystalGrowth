function f = Fu(phi)
%双井势函数
global epsilon
f = (1/(4*epsilon^2))*(phi.^2 - 1).^2; 
end