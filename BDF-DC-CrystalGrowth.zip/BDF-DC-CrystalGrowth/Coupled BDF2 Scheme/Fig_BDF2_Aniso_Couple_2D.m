clear all; close all;
tic
N = 128   ; %空间剖分数目
L = 2*pi  ; %空间剖分区间长度
global tau epsilon lambda D K sigma m theta0
%节点坐标
x   = (L/N)*(1/2:1:N-1/2); y = x;
%x = (L/N)*(0:N-1); y = x       ; %空间剖分坐标
hx = L/N; hy = hx               ; %空间步长
[X,Y] = meshgrid(x,y)           ; %二维空间坐标
X1 = X(:); Y1 = Y(:)            ; %形成列向量
%构造有限差分矩阵
[~, ~, ~, ~,~,~, Ex, Ey, Kx, Ky, D2] = Finite_difference_matrix_2D(N);
%初始条件
phi_0      = tanh((1.5-sqrt((X-pi).^2+(Y-pi).^2))/0.1); %初始条件
u_0          = -0.55*ones(N,N);
phi_0 = phi_0(:); u_0 = u_0(:);

%数值求解
dt = 1/100    ; %时间步长
T  = 2       ; %终止时间
tau = 1e2; epsilon = 0.1; lambda = 1; D = 2.25e-1; K = 1; sigma = 0.05; %r0 = 1.5, 0.1
S1 = 4; S2 = 4; m = 4; theta0 = 0            ;
M  = round(T/dt)                             ; %时间迭代数目
II = speye(N^2)                              ; %单位矩阵
Energy = zeros(M+1,1)                                                                              ; %定义能量零矩阵
Energy(1) = hx*hy*( -0.5*sum(phi_0.*m_grad(phi_0,N,L)) + lambda/(2*epsilon*K)*sum(u_0.^2) +...
(1/(4*epsilon^2))*sum((phi_0.^2-1).^2) ); %初始能量
%------------------耦合格式---------------------%
%---------Euler--[t0, t1]----------------------%
A1 = [(tau/dt + S2/epsilon^2)*II - S1*D2, diag(4*lambda*epsilon*Fu(phi_0)); diag(-4*epsilon^2*K*Fu(phi_0)), II-D*dt*D2];
B1 = [(tau/dt)*phi_0 + grad_Hm(phi_0,N,L) - S1*D2*phi_0 - dFu(phi_0) + (S2/epsilon^2)*phi_0; u_0 - 4*epsilon^2*K*Fu(phi_0).*phi_0]; 
A1 = sparse(A1); B1 = sparse(B1);

phi_u_h = A1 \ B1; %数值解

phi_1 = phi_u_h(1:N^2,:); u_1 = phi_u_h(N^2+1:2*N^2,:);

Energy(2) = hx*hy*( -0.5*sum(phi_1.*m_grad(phi_1,N,L)) + lambda/(2*epsilon*K)*sum(u_1.^2) +...
(1/(4*epsilon^2))*sum((phi_1.^2-1).^2) ); %初始能量
%--------------BDF2---[tn, tn+1]--------------%
for k = 2:M
phi_bar = 2*phi_1 - phi_0; u_bar   = 2*u_1 - u_0;
A2 = [(3*tau/(2*dt) + S2/epsilon^2)*II - S1*D2, diag(4*lambda*epsilon*Fu(phi_bar)); diag(-12*epsilon^2*K*Fu(phi_bar)), 3*II - 2*dt*D*D2];
B2 = [(tau/(2*dt))*(4*phi_1 - phi_0) + (S2/epsilon^2)*phi_bar - S1*D2*phi_bar + grad_Hm(phi_bar,N,L) - (2*dFu(phi_1) - dFu(phi_0)); 4*u_1 - u_0 - 4*epsilon^2*K*Fu(phi_bar).*(4*phi_1 - phi_0)]; 

phi_u_h = A2\B2;

phi_2 = phi_u_h(1:N^2,:); u_2 = phi_u_h(N^2+1:2*N^2,:);

phi_0 = phi_1; phi_1 = phi_2; u_0 = u_1; u_1 = u_2;

Energy(k+1) = hx*hy*( -0.5*sum(phi_2.*m_grad(phi_2,N,L)) + lambda/(2*epsilon*K)*sum(u_2.^2) +...
(1/(4*epsilon^2))*sum((phi_2.^2-1).^2) ); %初始能量

end
phi_h = reshape(phi_2,N,N); u_h = reshape(u_2,N,N);

format short e
figure(1)
Tt = (0:dt:T)'                                              ; %时间层的节点剖分
plot(Tt,Energy,'-b')
xlabel('Time','fontsize',10); ylabel('Energy','fontsize',10); %y轴坐标值

toc
