clear all; close all;
tic
N = 32   ; %空间剖分数目
L = 2*pi ; %空间剖分区间长度
global tau epsilon lambda D K sigma m theta0
%节点坐标
x   = (L/N)*(1/2:1:N-1/2); y = x;
%x = (L/N)*(0:N-1); y = x; %空间剖分坐标
hx = L/N; hy = hx               ; %空间步长
[X1,Y1] = meshgrid(x,y)         ; %二维空间坐标
X = X1(:); Y = Y1(:)            ; %形成列向量
%构造谱求导矩阵
% h = 2*pi/N; column = [-pi^2/(3*h^2)-1/6 -0.5*(-1).^(1:N-1)./sin((1:N-1)*h/2).^2]; %构造二阶谱求导列矩阵
% D22 = (2*pi/L)^2*toeplitz(column)                ; %构造一维求导矩阵
% I = speye(N); D2 = kron(D22,I) + kron(I,D22); %构造二维谱求导矩阵

%构造有限差分矩阵
[~, ~, ~, ~,~,~, ~, ~, ~, ~, D2] = Finite_difference_matrix_2D(N);

%数值求解
Tau = [1/20 1/40 1/80]; 
for i = 1:length(Tau)
%初始条件
[phi_0, u_0] = u_exact(X, Y, 0); %初始条件
%数值求解
dt = Tau(i)                   ; %时间步长
T  = 1                        ; %终止时间
tau = 4e3; epsilon = 1; lambda = 1; D = 1; K = 0.01; sigma = 0.05; %粘性系数
S1 = 4; S2 = 4; m = 4; theta0 = 0;
M  = round(T/dt)                                     ; %时间迭代数目
II = speye(N^2)                                      ; %单位矩阵

%-------------------耦合系统格式-----------------%
for k = 1:1
A1 = [(tau/dt + S2/epsilon^2)*II - S1*D2, diag(4*lambda*epsilon*Fu(phi_0)); diag(-4*epsilon^2*K*Fu(phi_0)), II-D*dt*D2];
B1 = [(tau/dt)*phi_0 + grad_Hm(phi_0,N,L) - S1*D2*phi_0 - dFu(phi_0) + (S2/epsilon^2)*phi_0; u_0 - 4*epsilon^2*K*Fu(phi_0).*phi_0]; %不含source项
A1 = sparse(A1); B1 = sparse(B1);

phi_u_h = A1 \ B1; %数值解

phi_1 = phi_u_h(1:N^2,:); u_1 = phi_u_h(N^2+1:2*N^2,:);

%phi_0 = phi_2; u_0 = u_2;

end
for k = 2:M
phi_bar = 2*phi_1 - phi_0; u_bar   = 2*u_1 - u_0;
A2 = [(3*tau/(2*dt) + S2/epsilon^2)*II - S1*D2, diag(4*lambda*epsilon*Fu(phi_bar)); diag(-12*epsilon^2*K*Fu(phi_bar)), 3*II - 2*dt*D*D2];
B2 = [(tau/(2*dt))*(4*phi_1 - phi_0) + (S2/epsilon^2)*phi_bar - S1*D2*phi_bar + grad_Hm(phi_bar,N,L) - (2*dFu(phi_1) - dFu(phi_0)); 4*u_1 - u_0 - 4*epsilon^2*K*Fu(phi_bar).*(4*phi_1 - phi_0)]; %不含source项

phi_u_h = A2\B2;

phi_2 = phi_u_h(1:N^2,:); u_2 = phi_u_h(N^2+1:2*N^2,:);

phi_0 = phi_1; phi_1 = phi_2; u_0 = u_1; u_1 = u_2;
end

phi_h = phi_2; u_h = u_2;

PHI(:,i) = phi_h; U(:,i) = u_h;
end

format short e

for j = 1:length(Tau) - 1

L_2_error_phi(j,1) = sqrt(sum((abs(PHI(:,j) - PHI(:,j+1))).^2))/N; 
L_2_error_u(j,1) = sqrt(sum((abs(U(:,j) - U(:,j+1))).^2))/N      ; 
end
for j = 1:length(L_2_error_phi) - 1
    Rate_phi(j,1) = log2( L_2_error_phi(j) / L_2_error_phi(j+1) );
    Rate_u(j,1) = log2( L_2_error_u(j) / L_2_error_u(j+1) )           ;
end
L_2_error_phi
Rate_phi

L_2_error_u
Rate_u

% format short e
% 
% load('phi_e.mat')
% 
% L_2_error_phi = sqrt(sum((abs(phi_h - phi_e)).^2))/N  %L_2 error
% L_2_error_u   = sqrt(sum((abs(u_h - u_e)).^2))/N     %L_2 error

toc