function fu = dFu(phi)
%非线性函数
global epsilon
fu  = (1/epsilon^2)*(phi.^3 - phi); %能量函数项  
end
