function Hm_grad = grad_Hm(phi,N,L)
%计算grad*(grad(m) + grad(H))
global sigma m theta0

% %构造一阶谱求导矩阵
% h = 2*pi/N; column1 = [0 0.5*(-1).^(1:N-1).*cot((1:N-1)*h/2)]'; 
% Ex = (2*pi/L)*toeplitz(column1,column1([1 N:-1:2]))                 ; %一阶谱求导矩阵
% Ey = Ex                                                                                              ;
% %构造二阶谱求导矩阵
% h = 2*pi/N; column = [-pi^2/(3*h^2)-1/6 -0.5*(-1).^(1:N-1)./sin((1:N-1)*h/2).^2]; %构造二阶谱求导列矩阵
% Kx = (2*pi/L)^2*toeplitz(column); %构造一维求导矩阵
% Ky = Kx                                            ;

%构造有限差分格式
[~, ~, ~, ~,~,~, Ex, Ey, Kx, Ky, ~] = Finite_difference_matrix_2D(N);

%[Dx, Dy, Dxx, Dyy,Dxy,~, ~, ~, ~, ~, ~] = Finite_difference_matrix_2D(N,h);

%--------------------二维守恒型模型-------------------%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%X-direction
Phin = reshape(phi,N,N);
DxPhin=Phin*Ex';
DyPhin=Ey*Phin;
DxxPhin=Phin*Kx';
theta=atan2(DyPhin,DxPhin);
Kappa=1+sigma*cos(m*(theta-theta0));
DKappa=-m*sigma*sin(m*(theta-theta0));
Kappa2=Kappa.^2 ;
Hmx=Kappa2.*DxxPhin+(Kappa2*Ex').*DxPhin-(DyPhin.*(Kappa.*DKappa))*Ex';
      
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Y-direction
DxPhin=Phin*Ex';
DyPhin=Ey*Phin;
DyyPhin=Ky*Phin;
theta=atan2(DyPhin,DxPhin);
Kappa=1+sigma*cos(m*(theta-theta0));
DKappa=-m*sigma*sin(m*(theta-theta0));
Hmy=Kappa2.*DyyPhin+(Ey*Kappa2).*DyPhin+Ey*((Kappa.*DKappa).*DxPhin);
Hm_grad = Hmx(:) + Hmy(:);

%---------------------二维非守恒型模型------------------%
% Phin = reshape(phi,N,N); Dx=Phin*Ex'; Dy=Ey*Phin; Dxx=Phin*Kx';
% Dyy=Ky*Phin; Dxy = (Ey*Phin)*Ex'; 
% % Dx = Dx*phi; Dy = Dy*phi; Dxx = Dxx*phi; Dyy = Dyy*phi; Dxy = Dxy*phi;
% theta      = atan2(Dy,Dx);  
% mphi        = 1+sigma*cos(m*(theta-theta0)); 
% Dmphi      = m*sigma*sin(m*(theta-theta0));
% mphi2      = mphi.^2 ;
% 
% % thetax = (Dxy.*Dx - Dy.*Dxx)./(Dx.^2 + Dy.^2 + 10^(-10)); 
% % thetay = (Dyy.*Dx - Dxy.*Dy)./(Dx.^2 + Dy.^2 + 10^(-10));
% % Hmxy    = mphi2.*(Dxx + Dyy) - 2*Dmphi.*mphi.*(thetax.*Dx + thetay.*Dy)+...
% % (m^2*sigma^2*cos(2*m*(theta-theta0)) + m^2*sigma*cos(m*(theta-theta0))).*(thetax.*Dy - thetay.*Dx); %最好的格式
% % 
% % Hm_grad = Hmxy(:);
% 
% Hmxy          = mphi2.*(Dxx + Dyy) - 2*mphi.*Dmphi.*(cos(2*theta).*Dxy + (1/2)*sin(2*theta).*(Dyy - Dxx)) +...
% (Dmphi.^2 - m^2*sigma*mphi.*cos(m*(theta-theta0))).*((1/2)*(Dxx + Dyy) + (1/2)*cos(2*theta).*(Dyy - Dxx) - Dxy.*sin(2*theta)); %完全展开
% 
% % Hmxy          = (1+sigma^2/2+2*sigma*cos(m*(theta-theta0)) + (sigma^2/2)*cos(2*m*(theta-theta0))).*(Dxx + Dyy) - (2*sigma*m*sin(m*(theta-theta0)) + m*sigma^2*sin(2*m*(theta-theta0))).*(cos(2*theta).*Dxy + (1/2)*sin(2*theta).*(Dyy - Dxx)) +...
% % (- m^2*sigma^2*cos(2*m*(theta-theta0)) - m^2*sigma*cos(m*(theta-theta0))).*((1/2)*(Dxx + Dyy) + (1/2)*cos(2*theta).*(Dyy - Dxx) - Dxy.*sin(2*theta)); %完全展开
% 
% Hm_grad = Hmxy(:);

% Hmxy    = mphi2.*(Dxx + Dyy) - 2*Dmphi.*mphi.*(thetax.*Dx + thetay.*Dy)+...
% (-Dmphi.^2 + m^2*sigma*mphi.*cos(m*(theta-theta0))).*(thetax.*Dy - thetay.*Dx);
end

%%
% [Dx, Dy, Dxx, Dyy,Dxy,Dyx, ~, ~, ~, ~, ~] = Finite_difference_matrix_2D(N);

%构造一阶谱求导矩阵
% h = 2*pi/N; column1 = [0 0.5*(-1).^(1:N-1).*cot((1:N-1)*h/2)]'; 
% D1 = (2*pi/L)*toeplitz(column1,column1([1 N:-1:2]))                 ; %一阶谱求导矩阵
% I = speye(N); Dx = kron(D1,I); Dy = kron(I,D1); Dxy = Dx*Dy; Dyx = Dxy;                                                                                              
% %构造二阶谱求导矩阵
% h = 2*pi/N; column = [-pi^2/(3*h^2)-1/6 -0.5*(-1).^(1:N-1)./sin((1:N-1)*h/2).^2]; %构造二阶谱求导列矩阵
% D2 = (2*pi/L)^2*toeplitz(column); %构造一维求导矩阵
% Dxx = kron(D2,I); Dyy = kron(I,D2);
% phi = sparse(phi);
% Hm_grad = ( ((((1 + sigma)*((Dy*phi).^4 + (Dx*phi).^4) - 2*(-1 + 3*sigma)*(Dy*phi).^2.*(Dx*phi).^2).*(32*sigma*(Dy*phi).*((Dy*phi) - (Dx*phi)).*(Dx*phi).^3.*((Dy*phi) + (Dx*phi)).*(Dyx*phi) +...
% (Dxx*phi).*((-(-3 + 37*sigma)).*(Dy*phi).^4.*(Dx*phi).^2 + 3*(1 + 9*sigma)*(Dy*phi).^2.*(Dx*phi).^4 + (1 + sigma)*((Dy*phi).^2 + (Dx*phi).^2).*((Dy*phi).^4 - (Dy*phi).^2.*(Dx*phi).^2 + (Dx*phi).^4)))) +...
% ((((Dx*phi).^4 + (Dy*phi).^4)*(1 + sigma) - 2*(Dx*phi).^2.*(Dy*phi).^2*(-1 + 3*sigma)).*((Dyy*phi).*(((Dx*phi).^2 + (Dy*phi).^2).^3 + ((Dx*phi).^4.*((Dx*phi).^2 - 37*(Dy*phi).^2) + (Dy*phi).^4.*(27*(Dx*phi).^2 + (Dy*phi).^2))*sigma) +...
% 32*(Dx*phi).*(Dxy*phi).*((Dx*phi) - (Dy*phi)).*(Dy*phi).^3.*((Dx*phi) + (Dy*phi))*sigma))) -((16*sigma*((Dy*phi).^6.*((Dy*phi).^2*(1 + sigma) - 4*(Dx*phi).^2*(1 + 7*sigma)) + (Dx*phi).^4.*((Dx*phi).^2.*((Dx*phi).^2*(1 + sigma) - 4*(Dy*phi).^2) -...
% 2*(Dy*phi).^2.*(14*(Dx*phi).^2*sigma - 5*(Dy*phi).^2*(-1 + 7*sigma)))).*((Dx*phi).*(-2*(Dxy*phi).*(Dy*phi) + (Dx*phi).*(Dyy*phi)) +...
% (Dy*phi).^2.*(Dxx*phi)))) )./( ((Dy*phi).^2 + (Dx*phi).^2).^5 );













